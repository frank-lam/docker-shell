package org.fengfei.lanproxy.common.container;

public interface Container {

    void start();

    void stop();
}
